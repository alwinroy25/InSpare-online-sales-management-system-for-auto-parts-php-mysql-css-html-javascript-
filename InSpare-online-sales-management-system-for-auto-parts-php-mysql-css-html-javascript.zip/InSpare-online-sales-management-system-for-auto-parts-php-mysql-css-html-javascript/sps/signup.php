<?php
session_start();
include_once('includes/config.php');
error_reporting(0);
if(isset($_POST['submit']))
{
    $name = $_POST['fullname'];
    $email = $_POST['emailid'];
    $contactno = $_POST['contactnumber'];
    $password = md5($_POST['inputuserpwd']);
    $sql = mysqli_query($con, "select id from users where email='$email'");
    $count = mysqli_num_rows($sql);
    if($count == 0){
        $query = mysqli_query($con, "insert into users(name,email,contactno,password) values('$name','$email','$contactno','$password')");
        if($query)
        {
            echo "<script>alert('You are successfully registered');</script>";
            echo "<script type='text/javascript'> document.location ='login.php'; </script>";
        }
        else{
            echo "<script>alert('Not registered, something went wrong');</script>";
            echo "<script type='text/javascript'> document.location ='signup.php'; </script>";
        }
    } else {
        echo "<script>alert('Email id already registered with another account. Please try with another email id.');</script>";
        echo "<script type='text/javascript'> document.location ='signup.php'; </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Shopping | User Sign up</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <script src="js/jquery.min.js"></script>
    <style>
        header {
            background: url('assets/1.png') center/cover no-repeat;
            color: #fff;
            text-align: center;
            padding: 100px 0;
            overflow: hidden;
        }
    </style>
    <script type="text/javascript">
        function validateName() {
            var name = document.getElementById('fullname').value;
            // Check if the name contains only alphabets
            if (!/^[a-zA-Z\s]+$/.test(name)) {
                alert("Invalid name format. Please enter only alphabets.");
                return false;
            }
            return true;
        }

        function validateEmail() {
            var email = document.getElementById('emailid').value;
            // Email validation
            var emailRegex = /^\S+@\S+\.\S+$/;
            if (!emailRegex.test(email)) {
                alert("Invalid email format");
                return false;
            }
            return true;
        }

        function validateContactNumber() {
            var contactNumber = document.getElementById('contactnumber').value;
            // Contact number validation (must be exactly 10 digits)
            if (!/^\d{10}$/.test(contactNumber)) {
                alert("Invalid contact number format (must be 10 digits)");
                return false;
            }
            return true;
        }

        function validatePassword() {
            var password = document.getElementById('inputuserpwd').value;
            // Password validation (must have at least 6 characters with 1 digit, 1 alphabet, and 1 special character)
            var passwordRegex = /^(?=.*\d)(?=.*[a-zA-Z])(?=.*[@#$%^&*()_+!])[0-9a-zA-Z@#$%^&*()_+!]{6,}$/;
            if (!passwordRegex.test(password)) {
                alert("Invalid password format. It must contain at least 6 characters with at least 1 digit, 1 alphabet, and 1 special character");
                return false;
            }
            return true;
        }

        function validateForm() {
            return validateName() && validateEmail() && validateContactNumber() && validatePassword();
        }
    </script>
</head>
<style type="text/css">
    input { border:solid 1px #000; }
</style>
<body>
<?php include_once('includes/header.php');?>
<!-- Header-->
<header class="bg-dark py-5">
    <div class="container px-4 px-lg-5 my-5">
        <div class="text-center text-white">
            <h1 class="display-4 fw-bolder">User Signup</h1>
            <p class="lead fw-normal text-white-50 mb-0">One Time Registration is Required for Shopping</p>
        </div>
    </div>
</header>
<!-- Section-->
<section class="py-5">
    <div class="container px-4  mt-5">
        <form method="post" name="signup" onsubmit="return validateForm();">
            <div class="row">
                <div class="col-2">Full Name</div>
                <div class="col-6"><input type="text" name="fullname" class="form-control" required required maxlength="25"></div>
            </div>
            <div class="row mt-3">
                <div class="col-2">Email Id</div>
                <div class="col-6">
                    <input type="email" name="emailid" id="emailid" class="form-control" onBlur="emailAvailability()" required>
                    <span id="user-email-status" style="font-size:12px;"></span>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-2">Contact Number</div>
                <div class="col-6">
                    <input type="text" name="contactnumber" pattern="[0-9]{10}" title="10 numeric characters only" class="form-control" required maxlength="10" >
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-2">Password</div>
                <div class="col-6"><input type="password" name="inputuserpwd" class="form-control" required></div>
            </div>
            <div class="row mt-3">
                <div class="col-4">&nbsp;</div>
                <div class="col-6"><input type="submit" name="submit" id="submit" class="btn btn-primary" required></div>
            </div>
        </form>
    </div>
</section>
<!-- Footer-->
<?php include_once('includes/footer.php'); ?>
<!-- Bootstrap core JS-->
<script src="js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
</body>
</html>
