<?php session_start();
error_reporting(0);
include_once('includes/config.php');
if(strlen( $_SESSION["aid"])==0)
{   
header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        $fdate = $_POST['fromdate'];
        $tdate = $_POST['todate'];
    }
}
function getOrderCount($con, $fdate, $tdate, $status = null)
{
    $query = "SELECT COUNT(*) as orderCount FROM `orders` WHERE orderDate BETWEEN '$fdate' AND '$tdate'";
    
    if ($status !== null) {
        $query .= " AND orderStatus = '$status'";
    }

    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);

    return $row['orderCount'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>InSpare | Between Dates Order Count</title>
    <link href="css/styles.css" rel="stylesheet" />
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin-top: 20px;
        }

        .card {
            margin-top: 20px;
        }

        .card-body {
            padding: 20px;
            background-color: #ffffff;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1, h4 {
            color: #007bff;
        }

        hr {
            border-top: 2px solid #007bff;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        h5 {
            margin-bottom: 10px;
        }
    </style>
</head>
    <body>
    <?php include_once('includes/header.php');?>
    <div id="layoutSidenav">
        <?php include_once('includes/sidebar.php');?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">B/w Dates Order Count</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">B/w Dates Order Count</li>
                    </ol>
                    <div class="card mb-4">
                        <div class="card-body">
                            <form method="post">
                                <div class="row">
                                    <div class="col-2">From Date</div>
                                    <div class="col-4"><input type="date" name="fromdate" class="form-control" required></div>
                                </div>
                                <div class="row" style="margin-top:1%;">
                                    <div class="col-2">To Date</div>
                                    <div class="col-4"><input type="date" name="todate" class="form-control" required></div>
                                </div>
                                <div class="row" style="margin-top:1%;">
                                    <div class="col-6" align="center"><button type="submit" name="submit" class="btn btn-primary">Submit</button></div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php if (isset($_POST['submit'])) { ?>
                        <div class="card mb-4">
                            <div class="card-body">
                                <h4 align="center">Order Counts From <?php echo $fdate; ?> To <?php echo $tdate; ?></h4>
                                <hr />

                                <div>
                                    <h5>Total Orders: <?php echo getOrderCount($con, $fdate, $tdate); ?></h5>
                                    <h5>Delivered Orders: <?php echo getOrderCount($con, $fdate, $tdate, 'Delivered'); ?></h5>
                                    <h5>Packed Orders: <?php echo getOrderCount($con, $fdate, $tdate, 'Packed'); ?></h5>
                                    <h5>Cancelled Orders: <?php echo getOrderCount($con, $fdate, $tdate, 'Cancelled'); ?></h5>
                                    <h5>Dispatched Orders: <?php echo getOrderCount($con, $fdate, $tdate, 'Dispatched'); ?></h5>
                                    <h5>In Transit Orders: <?php echo getOrderCount($con, $fdate, $tdate, 'In Transit'); ?></h5>
                                    <h5>Out For Delivery Orders: <?php echo getOrderCount($con, $fdate, $tdate, 'Out For Delivery'); ?></h5>
                                    <h5>New Orders: <?php echo getOrderCount($con, $fdate, $tdate, null); ?></h5>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </main>
            <?php include_once('includes/footer.php');?>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>
</html>
<?php  ?>
