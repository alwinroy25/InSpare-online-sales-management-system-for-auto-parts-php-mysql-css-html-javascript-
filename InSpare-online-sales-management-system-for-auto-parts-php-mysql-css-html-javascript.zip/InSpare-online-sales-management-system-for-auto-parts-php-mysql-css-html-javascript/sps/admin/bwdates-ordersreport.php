<?php session_start();
include_once('includes/config.php');
if(strlen( $_SESSION["aid"])==0)
{   
header('location:logout.php');
} else {
    function displayOrdersByProductStatus($con, $productStatus, $startDate, $endDate)
{
    if ($productStatus === 'all') {
        // Display all orders irrespective of status
        $query = "SELECT orders.id, orderNumber, totalAmount, orderStatus, orderDate, users.name, users.contactno 
            FROM `orders` 
            JOIN users ON users.id = orders.userId 
            WHERE (orders.orderDate BETWEEN '$startDate' AND '$endDate')";
    } elseif ($productStatus === 'New Order') {
        // Include NULL and the specified order status
        $query = "SELECT orders.id, orderNumber, totalAmount, orderStatus, orderDate, users.name, users.contactno 
            FROM `orders` 
            JOIN users ON users.id = orders.userId 
            WHERE (orders.orderStatus IS NULL AND orders.orderDate BETWEEN '$startDate' AND '$endDate')";
    } else {
        // Include only the specified order status (excluding NULL)
        $query = "SELECT orders.id, orderNumber, totalAmount, orderStatus, orderDate, users.name, users.contactno 
            FROM `orders` 
            JOIN users ON users.id = orders.userId 
            WHERE (orders.orderStatus = '$productStatus' AND orders.orderDate BETWEEN '$startDate' AND '$endDate')";
    }

    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0) {
        echo '<table border="1">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Order No.</th>
                        <th>Order By</th>
                        <th>Order Amount</th>
                        <th>Order Date</th>
                        <th>Order Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>'; // Add tbody tag here
    
        $cnt = 1;
        while ($row = mysqli_fetch_array($result)) {
            echo '<tr>
                    <td>' . htmlentities($cnt) . '</td>
                    <td>' . htmlentities($row['orderNumber']) . '</td>
                    <td>' . htmlentities($row['name']) . '</td>
                    <td>' . htmlentities($row['totalAmount']) . '</td>
                    <td>' . htmlentities($row['orderDate']) . '</td>
                    <td>' . htmlentities($row['orderStatus']) . '</td>
                    <td>
                        <a href="order-details.php?orderid=' . $row['id'] . '" target="_blank">
                            <i class="fas fa-file fa-2x" title="View Order Details"></i>
                        </a>
                    </td>
                </tr>';
            $cnt++;
        }
    
        echo '</tbody></table>';
    } else {
        echo '<p>No orders found.</p>';
    }
    
}
function displayall($con, $productStatus, $startDate, $endDate)
{
    displayOrdersByProductStatus($con, $productStatus, $startDate, $endDate);
}

    // Function to display New Order orders
    function displayNewOrderOrders($con, $startDate, $endDate)
    {
        displayOrdersByProductStatus($con, 'New Order', $startDate, $endDate);
    }

    // Function to display Packed Orders
    function displayPackedOrders($con, $startDate, $endDate)
    {
        displayOrdersByProductStatus($con, 'Packed', $startDate, $endDate);
    }

    // Function to display Dispatched Orders
    function displayDispatchedOrders($con, $startDate, $endDate)
    {
        displayOrdersByProductStatus($con, 'Dispatched', $startDate, $endDate);
    }

    // Function to display In Transit Order orders
    function displayInTransitOrders($con, $startDate, $endDate)
    {
        displayOrdersByProductStatus($con, 'In Transit', $startDate, $endDate);
    }

    // Function to display Out for Delivery Order orders
    function displayOutForDeliveryOrders($con, $startDate, $endDate)
    {
        displayOrdersByProductStatus($con, 'Out For Delivery', $startDate, $endDate);
    }

    // Function to display Delivered Order orders
    function displayDeliveredOrders($con, $startDate, $endDate)
    {
        displayOrdersByProductStatus($con, 'Delivered', $startDate, $endDate);
    }

    // Function to display Cancelled Order orders
    function displayCancelledOrders($con, $startDate, $endDate)
    {
        displayOrdersByProductStatus($con, 'Cancelled', $startDate, $endDate);
    }

    // ... Your existing code ...

 
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>InSpare | Between Dates Order Report</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="js/all.min.js" crossorigin="anonymous"></script>
        <!-- Add the following styles to your head section -->
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px; /* Adjust margin as needed */
    }

    th, td {
        padding: 10px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2; /* Background color for header */
    }

    tbody tr:nth-child(even) {
        background-color: #f9f9f9; /* Background color for even rows */
    }

    tbody tr:hover {
        background-color: #e5e5e5; /* Background color on hover */
    }

    /* Adjust font size as needed */
    table, th, td {
        font-size: 14px;
    }
</style>
    </head>
    <body>
   <?php include_once('includes/header.php');?>
        <div id="layoutSidenav">
   <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">B/w Dates Order Report</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">B/w Dates Order Report</li>
                        </ol>
                        <div class="card mb-4">
                            <div class="card-body">
<form  method="post">                                
<div class="row">
<div class="col-2">From Date</div>
<div class="col-4"><input type="date"  name="fromdate" class="form-control" required></div>
</div>

<div class="row" style="margin-top:1%;">
<div class="col-2">To Date</div>
<div class="col-4"><input type="date"  name="todate" class="form-control" required></div>
</div>
<div class="form-group row">
    <label for="example-email-input" class="col-2 col-form-label">Request Type</label>
    <div class="col-10">
    <input type="radio" name="requesttype" value="all" checked="true">All
<input type="radio" name="requesttype" value="New Order">New Order
<input type="radio" name="requesttype" value="Packed">Packed Orders
        <input type="radio" name="requesttype" value="Dispatched">Dispatched Orders
        <input type="radio" name="requesttype" value="In Transit">In Transit Order
        <input type="radio" name="requesttype" value="Out For Delivery">Out for Delivery Order
        <input type="radio" name="requesttype" value="Delivered">Delivered Order
        <input type="radio" name="requesttype" value="Cancelled">Cancelled Order
    </div>
</div>
<div class="row" style="margin-top:1%;">
<div class="col-6" align="center"><button type="submit" name="submit" class="btn btn-primary">Submit</button></div>
</div>

</form>
<?php
if (isset($_POST['submit'])) {
        $fdate = $_POST['fromdate'];
        $tdate = $_POST['todate'];
        $requestType = $_POST['requesttype'];
    
        switch ($requestType) {
            case 'all':
                displayall($con, 'all', $fdate, $tdate);
                break;
            case 'New Order':
                displayNewOrderOrders($con, $fdate, $tdate);
                break;
            case 'Packed':
                displayPackedOrders($con, $fdate, $tdate);
                break;
            case 'Dispatched':
                displayDispatchedOrders($con, $fdate, $tdate);
                break;
            case 'In Transit':
                displayInTransitOrders($con, $fdate, $tdate);
                break;
            case 'Out For Delivery':
                displayOutForDeliveryOrders($con, $fdate, $tdate);
                break;
            case 'Delivered':
                displayDeliveredOrders($con, $fdate, $tdate);
                break;
            case 'Cancelled':
                displayCancelledOrders($con, $fdate, $tdate);
                break;
            default:
                // Handle other cases or display all orders
                break;
        }
    }
}
?>
                            </div>
                        </div>
                    </div>


                </main>
          <?php include_once('includes/footer.php');?>
            </div>
        </div>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
         <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php  ?>
