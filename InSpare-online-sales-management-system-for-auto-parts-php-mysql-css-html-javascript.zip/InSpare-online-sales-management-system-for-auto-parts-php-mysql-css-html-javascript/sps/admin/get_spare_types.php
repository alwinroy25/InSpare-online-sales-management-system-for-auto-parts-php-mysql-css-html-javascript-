// get_spare_types.php

<?php
include_once('includes/config.php');

$query = "SELECT * FROM sparetype";
$result = mysqli_query($con, $query);

echo '<option value="">Select Spare Type</option>';

while ($row = mysqli_fetch_array($result)) {
    echo '<option value="' . $row['type'] . '">' . $row['type'] . '</option>';
}
?>
