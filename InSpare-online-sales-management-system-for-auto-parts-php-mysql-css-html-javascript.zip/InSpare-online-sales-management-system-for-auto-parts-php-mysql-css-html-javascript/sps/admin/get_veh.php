<?php
include('includes/config.php');
if(!empty($_POST["subcat_id"])) 
{
 $id=intval($_POST['subcat_id']);
$query=mysqli_query($con,"SELECT vehiclename,id FROM vehicle WHERE subcategoryid=$id");
?>
<option value="">Select Vechicle</option>
<?php
 while($row=mysqli_fetch_array($query))
 {
  ?>
  <option value="<?php echo htmlentities($row['id']); ?>"><?php echo htmlentities($row['vehiclename']); ?></option>
  <?php
 }
}
?>