<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add your head content here -->
    <style>
        /* Add your custom styles here */
        .footer {
            background-color: #343a40; /* Set your preferred background color */
            padding: 20px 0;
            text-align: center;
        }

        .footer h5 {
            font-size: 1.5rem; /* Set your preferred font size */
            color: #fff; /* Set your preferred text color */
        }

        .footer ul {
            list-style: none;
            padding: 0;
        }

        .footer li {
            margin-bottom: 10px;
        }

        .footer a {
            color: #fff; /* Set your preferred text color */
            text-decoration: none;
            font-size: 1rem; /* Set your preferred font size */
            transition: color 0.3s ease-in-out; /* Smooth transition effect */
        }

        .footer a:hover {
            color: #427E93; /* Set your preferred hover color */
        }

        .footer p {
            color: #fff; /* Set your preferred text color */
            font-size: 1rem; /* Set your preferred font size */
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <!-- Your existing content -->

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="shop-categories.php">Shop</a></li>
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <h5>User Section</h5>
                    <ul class="list-unstyled">
                        <?php if ($_SESSION['id'] == 0) { ?>
                            <li><a href="login.php">Login</a></li>
                            <li><a href="signup.php">Sign Up</a></li>
                        <?php } else { ?>
                            <li><a href="my-wishlist.php">My Wishlist</a></li>
                            <li><a href="my-profile.php">My Profile</a></li>
                            <!-- Add more user-related links as needed -->
                        <?php } ?>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <h5>Connect With Us</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://www.facebook.com"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a href="https://twitter.com"><i class="fab fa-twitter"></i> Twitter</a></li>
                        <li><a href="https://plus.google.com"><i class="fab fa-google-plus"></i> Google+</a></li>
                        <li><a href="https://www.linkedin.com"><i class="fab fa-linkedin"></i> LinkedIn</a></li>
                    </ul>
                </div>
            </div>
            <p>
                "InSpare: Your Road to Reliability. Explore a world of premium vehicle spare parts at your fingertips. Unleash the power of precision and quality, ensuring your journey is always smooth. Drive with confidence, choose InSpare – where excellence meets the open road."
            </p>
            <p>Copyright &copy; InSpare <?php echo date('Y');?></p>
        </div>
    </footer>

    <!-- Your existing scripts and other content -->

</body>
</html>
