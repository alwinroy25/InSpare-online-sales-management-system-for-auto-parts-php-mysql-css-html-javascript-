<?php
session_start();
include_once('includes/config.php');
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>InSpare | Vehicle Type wise Shop </title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <!-- Bootstrap CSS for Carousel -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Custom styles -->
    <style>
        .header-section {
            position: relative;
            background: url('assets/1.png') center/cover no-repeat;
            color: #fff;
            text-align: center;
            padding: 100px 0;
            overflow: hidden; /* Hide overflowing content */
        }

        .header-section h1 {
            font-size: 3rem;
        }

        .about-us-description {
            text-align: justify;
            text-justify: inter-word;
            margin-bottom: 20px;
            font-size: 20px;
            line-height: 1.6;
            color: #333;
            width: 160%;
            margin-left: 10%;
        }

        .about-us-description strong {
            font-weight: bold;
            color: #427E93;
        }

        .about-us-description p {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }

        .about-us-description .icon {
            margin-right: 10px;
            font-size: 24px;
        }

        .carousel {
            width: 70%;
            margin-right: 20px;
        }

        .image-description-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .carousel-item img {
            max-height: 400px;
            width: auto;
            margin: 0 auto;
        }

        @media (max-width: 1000px) {
            .carousel {
                width: 100%;
                margin-right: 0;
                margin-bottom: 20px;
            }
            .image-description-container {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    <?php include_once('includes/header.php'); ?>
    <!-- Header-->
    <header class="header-section">
        <div class="container px-4 px-lg-5 my-5">
            <div class="text-center text-white">
                <h1 class="display-4 fw-bolder">About Us</h1>
            </div>
        </div>
    </header>
    <!-- Section-->
    <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">
            <div class="image-description-container">
                <!-- Image Carousel -->
                <div id="imageCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <!-- Image 1 -->
                        <div class="carousel-item active">
                            <img src="assets/example1.png" class="d-block w-100" alt="Example 1">
                        </div>
                        <!-- Image 2 -->
                        <div class="carousel-item">
                            <img src="assets/example2.png" class="d-block w-100" alt="Example 2">
                        </div>
                        <div class="carousel-item">
                            <img src="assets/example3.png" class="d-block w-100" alt="Example 3">
                        </div>
                        <!-- Add more images as needed -->
                    </div>
                </div>

                <!-- About Us Description -->
                <div class="col-lg-6">
                    <p class="about-us-description">
                        Welcome to <strong>InSpare</strong>, where reliability meets innovation on the road! At InSpare, we're not just an e-commerce platform; we're your trusted companion in ensuring your vehicle's optimal performance. Our passion drives us to deliver top-quality spare parts for all types of vehicles, empowering you to embark on your journeys with confidence.
                    </p>
                    <p class="about-us-description">
                        <span class="icon bi bi-check2"></span> Comprehensive Selection: Explore a vast array of spare parts catering to diverse vehicle models. We've curated a collection that aligns with the needs of your ride.
                    </p>
                    <p class="about-us-description">
                        <span class="icon bi bi-star"></span> Quality Assurance: We prioritize excellence. Each spare part undergoes rigorous quality checks to ensure durability, performance, and your peace of mind.
                    </p>
                    <p class="about-us-description">
                        <span class="icon bi bi-truck"></span> Universal Compatibility: Whether you drive a sleek sedan, a rugged SUV, or a powerful truck, <strong>InSpare</strong> has the right parts to keep your vehicle running smoothly.
                    </p>
                    <p class="about-us-description">
                        <span class="icon bi bi-cart"></span> Effortless Shopping: Our user-friendly platform makes it easy for you to find, order, and receive the spare parts you need, all from the comfort of your home.
                    </p>
                    <p class="about-us-description">
                        <span class="icon bi bi-truck"></span> Swift Delivery: We understand the importance of timely repairs. Count on <strong>InSpare</strong> for prompt and reliable delivery, so you can get back on the road without delay.
                    </p>
                    <p class="about-us-description">
                        Join the <strong>InSpare</strong> community and experience the difference. Your journey is our priority, and we're here to make it a seamless and enjoyable ride. Drive with <strong>InSpare</strong> – where every mile matters!
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer-->
    <?php include_once('includes/footer.php'); ?>
    <!-- Bootstrap core JS and Carousel JS -->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <!-- Core theme JS -->
    <script src="js/scripts.js"></script>
</body>

</html>
