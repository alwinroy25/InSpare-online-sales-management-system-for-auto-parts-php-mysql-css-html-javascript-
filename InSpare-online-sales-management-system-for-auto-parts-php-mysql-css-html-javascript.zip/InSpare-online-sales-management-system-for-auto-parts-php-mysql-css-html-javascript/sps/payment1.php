<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Portal</title>
    <style>
        /* Add your styles here */
        .credit-card-form {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-row {
            display: flex;
            justify-content: space-between;
        }

        .form-column {
            flex: 1;
            margin-right: 10px;
        }

        .click-button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .Image1 {
            width: 100%;
            max-width: 300px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="credit-card-form">
        <h2>PAYMENT PORTAL</h2>
        <img class="Image1" src="https://i.ibb.co/hgJ7z3J/6375aad33dbabc9c424b5713-card-mockup-01.png" alt="Card Mockup">
  
        <form onsubmit="return validateForm()">
            <div class="form-group">
                <label for="card-number">Card Number</label>
                <input type="text" id="card-number" placeholder="Card number" maxlength="16" required>
            </div>
            <div class="form-group">
                <label for="card-holder">Card Holder</label>
                <input type="text" id="card-holder" placeholder="Card holder's name" pattern="[A-Za-z ]+" required>
            </div>
            <div class="form-row">
                <div class="form-group form-column">
                    <label for="expiry-date">Expiry Date</label>
                    <input type="text" id="expiry-date" placeholder="MM/YY" pattern="(0[1-9]|1[0-2])\/\d{2}" required>
                </div>
                <div class="form-group form-column">
                    <label for="cvv">CVV</label>
                    <input type="text" id="cvv" placeholder="CVV" maxlength="3" pattern="\d{3}" required>
                </div>
            </div>
            <button type="submit" class="click-button" onclick="showLoading(event, this)">PAY NOW</button>
        </form>
    </div>

    <script>
        function validateForm() {
            if (!validateCreditCard() || !validateCardholderName() || !validateExpiryDate() || !validateCVV()) {
                return false;
            }
            return true;
        }

        function validateCreditCard() {
            var creditCardNumber = document.getElementById('card-number').value;
            var cardNumberRegex = /^\d{16}$/;
            if (!cardNumberRegex.test(creditCardNumber)) {
                alert('Please enter a valid 16-digit credit/debit card number.');
                return false;
            }
            return true;
        }

        function validateCardholderName() {
            var cardholderName = document.getElementById('card-holder').value;
            var nameRegex = /^[A-Za-z ]+$/;
            if (!nameRegex.test(cardholderName)) {
                alert('Please enter a valid cardholder name with only alphabets.');
                return false;
            }
            return true;
        }

        function validateExpiryDate() {
            var expiryDate = document.getElementById('expiry-date').value;
            var dateRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
            if (!dateRegex.test(expiryDate)) {
                alert('Please enter a valid expiry date in MM/YY format.');
                return false;
            }
            return true;
        }

        function validateCVV() {
            var cvv = document.getElementById('cvv').value;
            var cvvRegex = /^\d{3}$/;
            if (!cvvRegex.test(cvv)) {
                alert('Please enter a valid 3-digit CVV.');
                return false;
            }
            return true;
        }

        function showLoading(event, button) {
            event.preventDefault(); // Prevent form submission

            if (validateForm()) {
                button.innerHTML = "Processing Payment...";

                setTimeout(function() {
                    button.innerHTML = "Payment completed.";
                }, 3000); 
                alert("order placed")
                // Change to the desired duration in milliseconds
                window.location.href ='my-orders.php';
            }
        }
    </script>
</body>
</html>
