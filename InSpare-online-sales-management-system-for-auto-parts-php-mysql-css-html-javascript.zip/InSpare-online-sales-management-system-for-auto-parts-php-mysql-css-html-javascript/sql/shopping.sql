-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2023 at 12:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `billingAddress` varchar(30) DEFAULT NULL,
  `biilingCity` varchar(30) DEFAULT NULL,
  `billingState` varchar(30) DEFAULT NULL,
  `billingPincode` int(11) DEFAULT NULL,
  `billingCountry` varchar(30) DEFAULT NULL,
  `shippingAddress` varchar(30) DEFAULT NULL,
  `shippingCity` varchar(30) DEFAULT NULL,
  `shippingState` varchar(30) DEFAULT NULL,
  `shippingPincode` int(11) DEFAULT NULL,
  `shippingCountry` varchar(30) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `userId`, `billingAddress`, `biilingCity`, `billingState`, `billingPincode`, `billingCountry`, `shippingAddress`, `shippingCity`, `shippingState`, `shippingPincode`, `shippingCountry`, `postingDate`) VALUES
(8, 9, 'muttath', 'Ernakulam', 'kerala', 682308, 'India', 'muttath', 'Ernakulam', 'kerala', 682308, 'India', '2023-12-17 22:43:36'),
(9, 9, 'kolenchery', 'Ernakulam', 'kerala', 682310, 'India', 'kolenchery', 'Ernakulam', 'kerala', 682310, 'India', '2023-12-17 22:44:06'),
(10, 14, 'cherriyil', 'Ernakulam', 'kerala', 682308, 'India', 'cherriyil', 'Ernakulam', 'kerala', 682308, 'India', '2023-12-17 23:09:10'),
(11, 15, 'marril', 'Ernakulam', 'kerala', 682308, 'India', 'marril', 'Ernakulam', 'kerala', 682308, 'India', '2023-12-17 23:11:54'),
(12, 16, 'vincentl', 'Ernakulam', 'kerala', 682308, 'India', 'vincentl', 'Ernakulam', 'kerala', 682308, 'India', '2023-12-17 23:14:16');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productQty` int(11) DEFAULT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(15) DEFAULT NULL,
  `categoryDescription` longtext DEFAULT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `createdBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `creationDate`, `updationDate`, `createdBy`) VALUES
(12, 'CAR', 'Cars are four-wheeled motor vehicles designed primarily for the transportation of passengers. They come in various sizes, from compact to full-size, and can be powered by gasoline, diesel, electric, or hybrid engines.', '2023-10-16 22:45:20', '2023-12-17 21:17:47', 1),
(13, 'BIKE', 'Motorcycles, commonly known as bikes, are two-wheeled vehicles. They are often lighter and more maneuverable than cars, with various types such as sport bikes, cruisers, and touring bikes. Motorcycles are typically powered by internal combustion engines.', '2023-10-16 22:49:24', '2023-12-17 21:17:36', 1),
(14, 'TRUCK', 'Trucks are large motor vehicles designed for the transportation of cargo. They come in various sizes and configurations, such as pickup trucks, semi-trucks, and delivery trucks. Trucks are crucial for transporting goods over long distances and are often used in commercial and industrial settings.', '2023-10-17 05:28:48', '2023-12-17 21:17:22', 1),
(15, 'Van', 'Vans are typically larger than cars but smaller than trucks. They are designed to transport goods or passengers and come in various configurations, such as passenger vans, cargo vans, and minivans. Vans are commonly used for commercial purposes, family transportation, or as recreational vehicles.', '2023-12-17 21:16:01', '2023-12-17 21:17:00', 1),
(16, 'Bus', 'Buses are large vehicles designed to transport groups of people. They come in various sizes, from small minibuses to large coaches. Buses are commonly used for public transportation, school transportation, and long-distance travel.', '2023-12-17 21:16:20', '2023-12-17 21:17:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `orderNumber` bigint(12) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `addressId` int(11) DEFAULT NULL,
  `totalAmount` decimal(10,2) DEFAULT NULL,
  `txnType` varchar(20) DEFAULT NULL,
  `orderStatus` varchar(20) DEFAULT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `orderNumber`, `userId`, `addressId`, `totalAmount`, `txnType`, `orderStatus`, `orderDate`) VALUES
(73, 632033880, 9, 8, 34564.00, 'Cash on Delivery', 'Delivered', '2023-12-17 22:44:15'),
(74, 494320156, 9, 9, 62300.00, 'Credit/Debit Card', 'Packed', '2023-12-17 22:44:57'),
(75, 828772574, 9, 8, 19998.00, 'Cash on Delivery', 'Dispatched', '2023-12-17 22:46:25'),
(76, 245749377, 14, 10, 61400.00, 'Cash on Delivery', 'In Transit', '2023-12-17 23:09:16'),
(77, 548554330, 14, 10, 17500.00, 'Credit/Debit Card', 'Out For Delivery', '2023-12-17 23:09:31'),
(78, 329558257, 14, 10, 9999.00, 'Cash on Delivery', 'Cancelled', '2023-12-17 23:10:17'),
(79, 451322641, 15, 11, 29000.00, 'Cash on Delivery', 'Delivered', '2023-12-17 23:12:01'),
(80, 357120160, 15, 11, 13000.00, 'Cash on Delivery', 'Packed', '2023-12-17 23:12:11'),
(81, 459756724, 15, 11, 4000.00, 'Credit/Debit Card', 'Dispatched', '2023-12-17 23:12:57'),
(82, 956416709, 16, 12, 8000.00, 'Cash on Delivery', 'In Transit', '2023-12-17 23:14:22'),
(83, 623436049, 16, 12, 19998.00, 'Cash on Delivery', 'Delivered', '2023-12-17 23:14:42'),
(84, 571349895, 16, 12, 87000.00, 'Credit/Debit Card', 'Out For Delivery', '2023-12-17 23:15:01'),
(85, 473359498, 9, 9, 39996.00, 'Cash on Delivery', NULL, '2023-12-17 23:25:00');

-- --------------------------------------------------------

--
-- Table structure for table `ordersdetails`
--

CREATE TABLE `ordersdetails` (
  `id` int(11) NOT NULL,
  `orderNumber` bigint(12) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `orderStatus` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ordersdetails`
--

INSERT INTO `ordersdetails` (`id`, `orderNumber`, `userId`, `productId`, `quantity`, `orderDate`, `orderStatus`) VALUES
(119, 632033880, 9, 35, 2, '2023-12-17 22:44:15', NULL),
(120, 632033880, 9, 40, 1, '2023-12-17 22:44:15', NULL),
(122, 494320156, 9, 36, 2, '2023-12-17 22:44:57', NULL),
(123, 494320156, 9, 41, 1, '2023-12-17 22:44:57', NULL),
(125, 828772574, 9, 37, 2, '2023-12-17 22:46:25', NULL),
(126, 245749377, 14, 40, 3, '2023-12-17 23:09:16', NULL),
(127, 245749377, 14, 36, 1, '2023-12-17 23:09:16', NULL),
(129, 548554330, 14, 41, 1, '2023-12-17 23:09:31', NULL),
(130, 329558257, 14, 37, 1, '2023-12-17 23:10:17', NULL),
(131, 451322641, 15, 39, 1, '2023-12-17 23:12:01', NULL),
(132, 357120160, 15, 40, 1, '2023-12-17 23:12:11', NULL),
(133, 459756724, 15, 34, 1, '2023-12-17 23:12:57', NULL),
(134, 956416709, 16, 38, 1, '2023-12-17 23:14:22', NULL),
(135, 623436049, 16, 37, 2, '2023-12-17 23:14:42', NULL),
(136, 571349895, 16, 39, 3, '2023-12-17 23:15:01', NULL),
(137, 473359498, 9, 37, 4, '2023-12-17 23:25:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ordertrackhistory`
--

CREATE TABLE `ordertrackhistory` (
  `id` int(11) NOT NULL,
  `orderId` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `remark` mediumtext DEFAULT NULL,
  `actionBy` int(3) DEFAULT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `canceledBy` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ordertrackhistory`
--

INSERT INTO `ordertrackhistory` (`id`, `orderId`, `status`, `remark`, `actionBy`, `postingDate`, `canceledBy`) VALUES
(31, 73, 'Packed', 'packed', 1, '2023-12-17 23:16:12', NULL),
(32, 73, 'Dispatched', 'order dispatched ', 1, '2023-12-17 23:16:38', NULL),
(33, 73, 'In Transit', 'on way', 1, '2023-12-17 23:16:52', NULL),
(34, 73, 'Out For Delivery', 'carrier on way', 1, '2023-12-17 23:17:20', NULL),
(35, 73, 'Delivered', 'thanks for shopping with us', 1, '2023-12-17 23:17:43', NULL),
(36, 74, 'Packed', 'order Packed', 1, '2023-12-17 23:18:01', NULL),
(37, 75, 'Packed', 'Order  Packed', 1, '2023-12-17 23:18:17', NULL),
(38, 75, 'Dispatched', 'order dispatched ', 1, '2023-12-17 23:18:51', NULL),
(39, 76, 'Packed', 'packed', 1, '2023-12-17 23:19:07', NULL),
(40, 76, 'Dispatched', 'dispatched ', 1, '2023-12-17 23:19:17', NULL),
(41, 76, 'In Transit', 'on way', 1, '2023-12-17 23:19:30', NULL),
(42, 77, 'Packed', 'packed', 1, '2023-12-17 23:19:49', NULL),
(43, 77, 'Dispatched', 'dispatched ', 1, '2023-12-17 23:20:00', NULL),
(44, 77, 'In Transit', 'on way', 1, '2023-12-17 23:20:10', NULL),
(45, 77, 'Out For Delivery', 'on way', 1, '2023-12-17 23:20:27', NULL),
(46, 78, 'Cancelled', 'cancelled', 1, '2023-12-17 23:20:49', ' Admin'),
(47, 79, 'Packed', 'packed', 1, '2023-12-17 23:21:20', NULL),
(48, 79, 'Dispatched', 'dispatched ', 1, '2023-12-17 23:21:30', NULL),
(49, 79, 'In Transit', 'on way', 1, '2023-12-17 23:21:39', NULL),
(50, 79, 'Out For Delivery', 'on way', 1, '2023-12-17 23:21:50', NULL),
(51, 79, 'Delivered', 'thanks for shopping with us', 1, '2023-12-17 23:21:59', NULL),
(52, 80, 'Packed', 'packed', 1, '2023-12-17 23:22:15', NULL),
(53, 81, 'Dispatched', 'despatched ', 1, '2023-12-17 23:22:28', NULL),
(54, 82, 'In Transit', 'on way', 1, '2023-12-17 23:22:40', NULL),
(55, 83, 'Out For Delivery', 'on way', 1, '2023-12-17 23:22:53', NULL),
(56, 84, 'Packed', 'packed', 1, '2023-12-17 23:23:21', NULL),
(57, 83, 'Delivered', 'delivered ', 1, '2023-12-17 23:23:41', NULL),
(58, 84, 'Dispatched', 'dispatched ', 1, '2023-12-17 23:24:00', NULL),
(59, 84, 'In Transit', 'on way', 1, '2023-12-17 23:24:10', NULL),
(60, 84, 'Out For Delivery', 'on way', 1, '2023-12-17 23:24:25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `subCategory` int(11) DEFAULT NULL,
  `vehiclename` varchar(11) DEFAULT NULL,
  `vehiclemodel` varchar(11) DEFAULT NULL,
  `sparetype` varchar(55) DEFAULT NULL,
  `productName` varchar(25) DEFAULT NULL,
  `productCompany` varchar(25) DEFAULT NULL,
  `productPrice` decimal(10,2) DEFAULT NULL,
  `productPriceBeforeDiscount` decimal(10,2) DEFAULT NULL,
  `productDescription` varchar(255) DEFAULT NULL,
  `productImage1` varchar(255) DEFAULT NULL,
  `productImage2` varchar(255) DEFAULT NULL,
  `productImage3` varchar(255) DEFAULT NULL,
  `shippingCharge` decimal(10,2) DEFAULT NULL,
  `productAvailability` int(11) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `addedBy` int(11) DEFAULT NULL,
  `lastUpdatedBy` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `subCategory`, `vehiclename`, `vehiclemodel`, `sparetype`, `productName`, `productCompany`, `productPrice`, `productPriceBeforeDiscount`, `productDescription`, `productImage1`, `productImage2`, `productImage3`, `shippingCharge`, `productAvailability`, `postingDate`, `updationDate`, `addedBy`, `lastUpdatedBy`) VALUES
(34, 12, 23, '14', '2021', 'Engine Parts', 'Turbocharger Upgrade Kit', 'Toyota', 4000.00, 5000.00, 'Turbocharger Upgrade Kit ', '6b26490421288797ba94ec5ed0b08281.png', '637894b38af57bd00672bb57ea74d684.png', 'ffe4d7331a7e457f159a75b1d280d84f.png', 300.00, 49, '2023-12-17 22:08:12', '2023-12-17 23:12:57', 1, NULL),
(35, 12, 24, '19', '2018', 'Brake System Pa', 'Sport Brake Upgrade Kit', 'Ford ', 10782.00, 12450.00, 'Enhanced stopping power for safety and control.', 'f6ee10daf7965424d2003ea57e5d6060jpeg', '590756936df2631b565edb071ed51a80jpeg', '4838e68cffe1c47651ce07381ab15cc2jpeg', 300.00, 8, '2023-12-17 22:14:19', '2023-12-17 22:44:15', 1, NULL),
(36, 15, 35, '31', 'EXH-3000', 'Exhaust System ', 'Touring Exhaust System', 'Benz', 22400.00, 23240.00, 'Reduced backpressure for improved performance.', '6df5007e8f18f547252ebd2054870a38jpeg', '6d6abc6b0e8b95a97d1121aa65c327c9jpeg', '2664cd68e501b32c5dc77c390efd2653jpeg', 1000.00, 2, '2023-12-17 22:18:33', '2023-12-17 23:09:16', 1, NULL),
(37, 13, 27, '23', 'LHD-500', 'Lights and Bulb', ' LED Headlight Conversion', 'Harley-Davidson', 9999.00, 11000.00, 'improved visibility and a modern look.', '4f0e1022db7e12b6029a5e12d953fc42jpeg', '6e82c8773398b37dfb8c325800ac4e2cjpeg', '6ea2c87d4057a743cbcbd8f5f526171bjpeg', 344.00, 26, '2023-12-17 22:21:27', '2023-12-17 23:25:00', 1, NULL),
(38, 14, 34, '29', '2015', 'Fuel System Par', 'Diesel Fuel Injector Set', 'Nissan', 8000.00, 12000.00, 'Improve fuel efficiency and power with this diesel fuel injector se', '14afe08ab2c5a73033c7358c109dc750jpeg', 'd0b93c49d7d88b743d7c88fbb7c542d3jpeg', '5f444b2ba190cc3a4c706f7ecae885dfjpeg', 300.00, 39, '2023-12-17 22:25:06', '2023-12-17 23:14:22', 1, NULL),
(39, 16, 39, '35', '2016', 'Suspension and ', 'Heavy-Duty Shock Absorber', 'volvo', 29000.00, 30000.00, 'Enhance road performance with these heavy-duty shock absorbers ', '73f5ee4119f0674cf6fa8f264b467968jpeg', 'd01479e28c65d7d2b76d7f899333da5ejpeg', '286e7165c0b1e7eb9091b43f95680a0djpeg', 1000.00, 49, '2023-12-17 22:27:59', '2023-12-17 23:15:01', 1, NULL),
(40, 13, 29, '27', 'v3', 'Engine Parts', 'High-Performance Camshaft', 'Yamaha ', 13000.00, 15000.00, 'kit is engineered to deliver an exhilarating riding experience', '3db331e92d75f901dc1de8c6271571ecjpeg', 'dd39ee0b82779818553353dcc0f146f7jpeg', 'd2fbfda64c862339b039d687127cf637jpeg', 245.00, 27, '2023-12-17 22:32:20', '2023-12-17 23:12:11', 1, NULL),
(41, 15, 35, '32', 'X7', 'Electrical Syst', 'Hybrid Battery Pack', 'Benz', 17500.00, 18000.00, 'hybrid battery pack for sustained fuel efficiency.', '43ad990fffbf1a0ccf2a978941de75d2jpeg', 'a3f153ee6baab07df4c1b5e6d8c8d765jpeg', '7afd556ba49db022e59e4dec56487146jpeg', 4323.00, 32, '2023-12-17 22:37:09', '2023-12-17 23:09:31', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sparetype`
--

CREATE TABLE `sparetype` (
  `id` int(11) NOT NULL,
  `type` varchar(35) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `createdBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sparetype`
--

INSERT INTO `sparetype` (`id`, `type`, `creationDate`, `updationDate`, `createdBy`) VALUES
(51, 'Engine Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:44', 1),
(52, 'Transmission and Clutch Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:46', 1),
(53, 'Suspension and Steering Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:48', 1),
(54, 'Brake System Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:50', 1),
(55, 'Exhaust System Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:52', 1),
(56, 'Electrical System Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:53', 1),
(57, 'Fuel System Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:55', 1),
(58, 'Cooling System Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:57', 1),
(59, 'Air Conditioning System Parts', '2023-12-17 21:51:31', '2023-12-17 21:51:58', 1),
(60, 'Filters', '2023-12-17 21:51:31', '2023-12-17 21:52:00', 1),
(61, 'Gaskets and Seals', '2023-12-17 21:51:31', '2023-12-17 21:52:01', 1),
(62, 'Belts and Pulleys', '2023-12-17 21:51:31', '2023-12-17 21:52:03', 1),
(63, 'Lights and Bulbs', '2023-12-17 21:51:31', '2023-12-17 21:52:05', 1),
(64, 'Wiper System Parts', '2023-12-17 21:51:31', '2023-12-17 21:52:08', 1),
(65, 'Body and Interior Parts', '2023-12-17 21:51:31', '2023-12-17 21:52:11', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `subcategoryName` varchar(25) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `createdBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategoryName`, `creationDate`, `updationDate`, `createdBy`) VALUES
(23, 12, 'Toyota', '2023-12-17 21:21:48', NULL, 1),
(24, 12, 'Ford', '2023-12-17 21:22:06', NULL, 1),
(26, 12, 'BMW', '2023-12-17 21:22:36', NULL, 1),
(27, 13, 'Harley-Davidson', '2023-12-17 21:22:55', NULL, 1),
(28, 13, 'Ducati', '2023-12-17 21:23:05', NULL, 1),
(29, 13, 'Yamaha', '2023-12-17 21:23:17', NULL, 1),
(34, 14, 'Nissan', '2023-12-17 21:24:40', NULL, 1),
(35, 15, 'Mercedes-Benz', '2023-12-17 21:25:07', NULL, 1),
(39, 16, 'Volvo', '2023-12-17 21:26:20', NULL, 1),
(42, 16, 'MAN', '2023-12-17 21:26:59', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contactNumber` bigint(12) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `username`, `password`, `contactNumber`, `creationDate`, `updationDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 7034443062, '2023-09-07 16:21:18', '2023-12-16 22:21:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `contactno`, `password`, `regDate`, `updationDate`) VALUES
(9, 'Alwin Roy', 'alwinroy25@gmail.com', 7034443062, '202cb962ac59075b964b07152d234b70', '2023-10-16 22:37:36', '2023-12-16 22:28:05'),
(14, 'Ashly Roy', 'ashly@gmail.com', 9946367943, '202cb962ac59075b964b07152d234b70', '2023-12-17 21:10:19', NULL),
(15, 'Stephin Mathew', 'stephin@gmail.com', 9605893381, '202cb962ac59075b964b07152d234b70', '2023-12-17 21:11:22', NULL),
(16, 'Amal M V', 'amal@gmail.com', 7034443069, '202cb962ac59075b964b07152d234b70', '2023-12-17 21:12:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `id` int(11) NOT NULL,
  `subcategoryid` int(11) DEFAULT NULL,
  `vehiclename` varchar(25) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `createdBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`id`, `subcategoryid`, `vehiclename`, `creationDate`, `updationDate`, `createdBy`) VALUES
(14, 23, 'Toyota Camry', '2023-12-17 21:31:31', NULL, 1),
(15, 23, 'Toyota Corolla', '2023-12-17 21:31:43', NULL, 1),
(16, 23, 'Toyota Prius', '2023-12-17 21:31:56', NULL, 1),
(17, 23, 'Toyota RAV4', '2023-12-17 21:32:10', NULL, 1),
(18, 24, 'Ford Mustang', '2023-12-17 21:34:00', NULL, 1),
(19, 24, 'Ford F-150', '2023-12-17 21:34:15', NULL, 1),
(20, 24, 'Ford Explorer', '2023-12-17 21:34:28', NULL, 1),
(21, 26, 'BMW 3 Series', '2023-12-17 21:35:18', NULL, 1),
(22, 26, 'BMW 5 Series', '2023-12-17 21:35:32', NULL, 1),
(23, 27, 'Harley-Davidson Street Gl', '2023-12-17 21:35:47', NULL, 1),
(24, 28, 'Ducati Panigale', '2023-12-17 21:35:58', NULL, 1),
(25, 28, 'Ducati Diavel', '2023-12-17 21:36:15', NULL, 1),
(26, 29, 'Yamaha YZF-R1', '2023-12-17 21:36:28', NULL, 1),
(27, 29, 'Yamaha MT-07', '2023-12-17 21:36:41', NULL, 1),
(28, 29, 'Yamaha FZ-09', '2023-12-17 21:36:55', NULL, 1),
(29, 34, 'Nissan Titan', '2023-12-17 21:37:08', NULL, 1),
(30, 34, 'Nissan Frontier', '2023-12-17 21:37:24', NULL, 1),
(31, 35, 'Mercedes-Benz Sprinter', '2023-12-17 21:37:38', NULL, 1),
(32, 35, 'Mercedes-Benz Metris', '2023-12-17 21:37:50', NULL, 1),
(33, 37, 'Volkswagen Transporter', '2023-12-17 21:38:01', NULL, 1),
(34, 37, 'Volkswagen Crafter', '2023-12-17 21:38:12', NULL, 1),
(35, 39, 'Volvo 9700', '2023-12-17 21:38:29', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `userId`, `productId`, `postingDate`) VALUES
(14, 9, 37, '2023-12-17 22:45:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userrrid` (`userId`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uiid` (`userID`),
  ADD KEY `piddd` (`productId`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uidddd` (`userId`),
  ADD KEY `addressid` (`addressId`),
  ADD KEY `orderNumber` (`orderNumber`);

--
-- Indexes for table `ordersdetails`
--
ALTER TABLE `ordersdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderidd` (`orderNumber`),
  ADD KEY `useridd` (`userId`),
  ADD KEY `productiddd` (`productId`);

--
-- Indexes for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderidddddd` (`orderId`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catidddd` (`category`),
  ADD KEY `subCategory` (`subCategory`);

--
-- Indexes for table `sparetype`
--
ALTER TABLE `sparetype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`categoryid`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usseridddd` (`userId`),
  ADD KEY `ppiidd` (`productId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `ordersdetails`
--
ALTER TABLE `ordersdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `sparetype`
--
ALTER TABLE `sparetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
